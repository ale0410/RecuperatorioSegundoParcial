namespace Personas{
    export enum eSexo{
        Masculino = "Masculino",
        Femenino = "Femenino",
    }

    export class Cliente extends Persona
    {
        private edad:number;
        private sexo:eSexo;

        constructor(id:number, nombre:string,apellido : string,edad : number, sexo:eSexo)
        {
            super(id,nombre,apellido);//llamo al constructor de la clase padre
            this.edad=edad;//inicializo atributos propios
            this.sexo = sexo;
        }

        public getEdad():number
        {
            return this.edad;
        }

        public setEdad(edad:number):void
        {
            this.edad=edad;
        }

        public getSexo():eSexo
        {
            return this.sexo;
        }

        public setSexo(sexo:eSexo):void
        {
            this.sexo = sexo;
        }
    }
}