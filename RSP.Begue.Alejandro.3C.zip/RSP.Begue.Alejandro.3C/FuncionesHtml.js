var Personas;
(function (Personas) {
    var listaPersonas = new Array();
    var row;
    window.onload = function () {
        var _a, _b, _c, _d, _e;
        (_a = document.getElementById("btnAgregar")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", Guardar);
        (_b = document.getElementById("btnEliminar")) === null || _b === void 0 ? void 0 : _b.addEventListener("click", Eliminar);
        (_c = document.getElementById("btnLimpiarTabla")) === null || _c === void 0 ? void 0 : _c.addEventListener("click", deleteRow);
        (_d = document.getElementById("tipoPersona")) === null || _d === void 0 ? void 0 : _d.addEventListener("change", SwapTables);
        (_e = document.getElementById("calcularPromedio")) === null || _e === void 0 ? void 0 : _e.addEventListener("click", CalcularPromedio);
    };
    function CalcularId() {
        var id = 1;
        if (listaPersonas.length != 0) {
            id = listaPersonas.reduce(function (idActual, idMayor) { return idActual > idMayor ? idMayor = idActual : idMayor; }).getId() + 1;
        }
        return id;
    }
    function Guardar() {
        var nombre = document.getElementById("nombrePost").value;
        var apellido = document.getElementById("apellidoPost").value;
        var edadStr = document.getElementById("edadPost").value;
        var sexoT = document.getElementById("sexoPost").value;
        var edadNum = parseInt(edadStr);
        var sexo;
        var personaPost;
        if (edadNum.toString() != null) {
            if (sexoT === "BoyPost") {
                sexo = Personas.eSexo.Masculino;
                personaPost = new Personas.Cliente(CalcularId(), nombre, apellido, edadNum, sexo);
            }
            else if (sexoT === "GirlPost") {
                sexo = Personas.eSexo.Femenino;
                personaPost = new Personas.Cliente(CalcularId(), nombre, apellido, edadNum, sexo);
            }
        }
        else {
            alert("Precio debe ser valor numerico");
        }
        listaPersonas.push(personaPost);
        var tablaPersonas = document.getElementById("tablePersons");
        ConstruirFila(tablaPersonas, personaPost.getId(), personaPost.getNombre(), personaPost.getApellido(), edadNum, sexo);
    }
    function deleteRow() {
        document.getElementById("tablePersons").deleteTHead;
    }
    /*function MostrarAtributosPropios()
    {
        var tipo = (<HTMLInputElement>document.getElementById("tipoPost")).value;
        var cuatroXCcuatro = (<HTMLInputElement>document.getElementById("cuatroXCuatroPost"));
        var cantPuertas = (<HTMLInputElement>document.getElementById("puertasPost"));

        switch(tipo)
        {
            case "AutoPost":
                cantPuertas.disabled = false;
                cuatroXCcuatro.disabled = true;
                break;
            case "CamionetaPost":
                cantPuertas.disabled = true;
                cuatroXCcuatro.disabled = false;
                break;
            default:
                cantPuertas.disabled = true;
                cuatroXCcuatro.disabled = true;
                break;
        }

    }*/
    function BuscarPersona() {
        var tipoSexo = document.getElementById("tipoPersona").value;
        return new Promise(function (resolve, reject) {
            var coincidencias = listaPersonas.filter(function (cliente) { return cliente.getSexo() === tipoSexo; });
            resolve(coincidencias);
        });
    }
    Personas.BuscarPersona = BuscarPersona;
    function SwapTables() {
        var tablaPersonas = document.getElementById("tablePersons");
        var tablaFiltrados = document.getElementById("tableFilters");
        if (document.getElementById("tipoPersona").value != "Todo") {
            tablaPersonas.hidden = true;
            tablaFiltrados.innerHTML = "";
            BuscarPersona().then(function (listaFiltrada) {
                listaFiltrada.forEach(function (Cliente) {
                    ConstruirFila(tablaFiltrados, Cliente.getId(), Cliente.getNombre(), Cliente.getApellido(), Cliente.getEdad(), Cliente.getSexo());
                });
            });
            tablaFiltrados.hidden = false;
        }
        else {
            tablaPersonas.hidden = false;
            tablaFiltrados.hidden = true;
        }
    }
    Personas.SwapTables = SwapTables;
    function CalcularPromedio() {
        BuscarPersona().then(function (listaCoincidencias) {
            var list = listaCoincidencias;
            var valorTotal = 0;
            if (list.length > 0) {
                valorTotal = list.reduce((function (total, per) { return total += per.getEdad(); }), 0);
                document.getElementById("promEdad").value = (valorTotal / list.length).toString();
            }
            else {
                valorTotal = listaPersonas.reduce((function (total, per) { return total += per.getEdad(); }), 0);
                document.getElementById("promEdad").value = (valorTotal / list.length).toString();
            }
            document.getElementById("promEdad").value = (valorTotal / listaPersonas.length).toString();
        });
    }
    Personas.CalcularPromedio = CalcularPromedio;
    function ConstruirFila(tabla, id, nombre, apellido, edad, sexo) {
        var tr = document.createElement("tr");
        var td = document.createElement("td");
        td.appendChild(document.createTextNode(id.toString()));
        tr.appendChild(td);
        var td2 = document.createElement("td");
        td2.appendChild(document.createTextNode(nombre));
        tr.appendChild(td2);
        var td3 = document.createElement("td");
        td3.appendChild(document.createTextNode(apellido));
        tr.appendChild(td3);
        var td4 = document.createElement("td");
        td4.appendChild(document.createTextNode(edad.toString()));
        tr.appendChild(td4);
        var td5 = document.createElement("td");
        td5.appendChild(document.createTextNode(sexo));
        tr.appendChild(td5);
        var td6 = document.createElement("td");
        var btnEliminar = document.createElement("button");
        btnEliminar.textContent = "Eliminar";
        btnEliminar.addEventListener('click', Personas.Eliminar);
        td6.appendChild(btnEliminar);
        tr.appendChild(td6);
        tabla.appendChild(tr);
    }
    Personas.ConstruirFila = ConstruirFila;
    function LlamadaEliminar(e) {
        e.preventDefault();
        var tagA = e.target;
        var tr = tagA.parentNode.parentNode;
        var idToMod = tr.childNodes[0].innerHTML;
        var listaId = listaPersonas.filter(function (Cliente) { return Cliente.getId() == idToMod; });
        if (listaId.length > 0) {
            listaPersonas.splice(idToMod, 1);
            var contenedor = document.getElementById("agregarPersona");
            var nombre = document.getElementById("nombrePost").value;
            var apellido = document.getElementById("apellidoPost").value;
            var edadStr = document.getElementById("edadPost").value;
            var tipoPersona = document.getElementById("sexoPost").value;
            var sexoT;
            var edadNum = parseInt(edadStr);
            nombre = tr.children[1].innerHTML;
            apellido = tr.children[2].innerHTML;
            edadNum = tr.children[3].innerHTML;
            tipoPersona = tr.children[4].innerHTML;
            contenedor.hidden = false;
            row = tr;
        }
    }
    Personas.LlamadaEliminar = LlamadaEliminar;
    function Eliminar(tr) {
        var trToDelete = tr.target.parentNode.parentNode;
        var idToDelete = trToDelete.childNodes[0].innerHTML;
        var listaId = listaPersonas.filter(function (Cliente) { return Cliente.getId() == idToDelete; });
        if (listaId.length > 0) {
            listaPersonas.splice(idToDelete, 1);
            var tablaPersonas = document.getElementById("tablePersons");
            var tablaFiltrados = document.getElementById("tableFilters");
            tablaPersonas.childNodes.forEach(function (element) {
                if (element.nodeName == "TR") {
                    if (element.childNodes[2].textContent == idToDelete) {
                        element.remove();
                        return;
                    }
                }
                trToDelete.remove();
            });
            tablaFiltrados.childNodes.forEach(function (element2) {
                if (element2.nodeName == "TR") {
                    if (element2.childNodes[2].textContent == idToDelete) {
                        element2.remove();
                        return;
                    }
                }
                trToDelete.remove();
            });
        }
    }
    Personas.Eliminar = Eliminar;
})(Personas || (Personas = {}));
