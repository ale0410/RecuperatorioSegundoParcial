namespace Personas{
    var listaPersonas = new Array<Cliente>();
    var row:any;

    window.onload = function()
    {
        document.getElementById("btnAgregar")?.addEventListener("click", Guardar);
        document.getElementById("btnEliminar")?.addEventListener("click", Eliminar);
        document.getElementById("btnLimpiarTabla")?.addEventListener("click", deleteRow);
        document.getElementById("tipoPersona")?.addEventListener("change", SwapTables);
        document.getElementById("calcularPromedio")?.addEventListener("click", CalcularPromedio);
    }

    function CalcularId() 
    {
        var id: number = 1;
        if (listaPersonas.length != 0) {
            id = listaPersonas.reduce((idActual, idMayor) => idActual > idMayor ? idMayor = idActual : idMayor).getId() + 1;
               
        }
            
        return id;
    }

    function Guardar()
    {
        var nombre: string = (<HTMLInputElement>document.getElementById("nombrePost")).value;
        var apellido: string = (<HTMLInputElement>document.getElementById("apellidoPost")).value;
        var edadStr: string = (<HTMLInputElement>document.getElementById("edadPost")).value;
        var sexoT: string = (<HTMLInputElement>document.getElementById("sexoPost")).value;
        var edadNum: number = parseInt(edadStr);
        var sexo: eSexo;
        var personaPost:Cliente;

        if (edadNum.toString() != null) 
        {
            if (sexoT === "BoyPost") {
                sexo = eSexo.Masculino;
                personaPost = new Cliente(CalcularId(), nombre, apellido, edadNum, sexo);
            }
            else if (sexoT === "GirlPost") {
                sexo = eSexo.Femenino;
                personaPost = new Cliente(CalcularId(), nombre, apellido, edadNum, sexo);
            }
        }
        else {
            alert("Precio debe ser valor numerico");
        }

        listaPersonas.push(personaPost);
            var tablaPersonas = (<HTMLTableElement>document.getElementById("tablePersons"));
            ConstruirFila(tablaPersonas, personaPost.getId(), personaPost.getNombre(),
            personaPost.getApellido(), edadNum, sexo);
    }

    function deleteRow() {
        (<HTMLTableElement>document.getElementById("tablePersons")).deleteTHead;
    }

    /*function MostrarAtributosPropios()
    {
        var tipo = (<HTMLInputElement>document.getElementById("tipoPost")).value;
        var cuatroXCcuatro = (<HTMLInputElement>document.getElementById("cuatroXCuatroPost"));
        var cantPuertas = (<HTMLInputElement>document.getElementById("puertasPost"));

        switch(tipo)
        {
            case "AutoPost":
                cantPuertas.disabled = false;
                cuatroXCcuatro.disabled = true;
                break;
            case "CamionetaPost":
                cantPuertas.disabled = true;
                cuatroXCcuatro.disabled = false;
                break;
            default:
                cantPuertas.disabled = true;
                cuatroXCcuatro.disabled = true;
                break;
        }

    }*/

    export function BuscarPersona() {
        var tipoSexo = (<HTMLInputElement>document.getElementById("tipoPersona")).value;
        return new Promise((resolve, reject) => {
            var coincidencias = listaPersonas.filter(cliente => cliente.getSexo() === tipoSexo);
            resolve(coincidencias);
        });
    }

    export function SwapTables() {
        var tablaPersonas = (<HTMLTableElement>document.getElementById("tablePersons"));
        var tablaFiltrados = (<HTMLTableElement>document.getElementById("tableFilters"));
        if ((<HTMLInputElement>document.getElementById("tipoPersona")).value != "Todo") {
            tablaPersonas.hidden = true;
            tablaFiltrados.innerHTML = "";
            BuscarPersona().then((listaFiltrada) => {
                (<Array<Cliente>>listaFiltrada).forEach(Cliente => {
                    
                    ConstruirFila(tablaFiltrados, (<Cliente>Cliente).getId(), (<Cliente>Cliente).getNombre(),
                    (<Cliente>Cliente).getApellido(), (<Cliente>Cliente).getEdad(), (<Cliente>Cliente).getSexo());
                });
            });
            tablaFiltrados.hidden = false;
        }
        else {
            tablaPersonas.hidden = false;
            tablaFiltrados.hidden = true;
        }
    }

    export function CalcularPromedio() {
        BuscarPersona().then((listaCoincidencias) => {
            var list = <Array<Cliente>>listaCoincidencias;
            var valorTotal: number = 0;
            if (list.length > 0) {
                valorTotal = list.reduce(((total, per) => total += per.getEdad()), 0);
                (<HTMLInputElement>document.getElementById("promEdad")).value = (valorTotal / list.length).toString();
            }
            else {
                valorTotal = listaPersonas.reduce(((total, per) => total += per.getEdad()), 0);
                (<HTMLInputElement>document.getElementById("promEdad")).value = (valorTotal / list.length).toString();
            }
            (<HTMLInputElement>document.getElementById("promEdad")).value = (valorTotal / listaPersonas.length).toString();
        });
    }

    export function ConstruirFila(tabla: HTMLTableElement, id: number, nombre: string,
        apellido: string, edad: number, sexo: eSexo): void {
        var tr = document.createElement("tr");

        var td = document.createElement("td");
        td.appendChild(document.createTextNode(id.toString()));
        tr.appendChild(td);

        var td2 = document.createElement("td");
        td2.appendChild(document.createTextNode(nombre));
        tr.appendChild(td2);

        var td3 = document.createElement("td");
        td3.appendChild(document.createTextNode(apellido));
        tr.appendChild(td3);

        var td4 = document.createElement("td");
        td4.appendChild(document.createTextNode(edad.toString()));
        tr.appendChild(td4);

        var td5 = document.createElement("td");
        td5.appendChild(document.createTextNode(sexo));
        tr.appendChild(td5);

        var td6 = document.createElement("td");
        var btnEliminar = document.createElement("button");
        btnEliminar.textContent = "Eliminar";
        btnEliminar.addEventListener('click', Personas.Eliminar);
        td6.appendChild(btnEliminar);
        tr.appendChild(td6);

        tabla.appendChild(tr);

    }

    export function LlamadaEliminar(e:any)
    {
        e.preventDefault();
        var tagA = e.target;
        var tr = tagA.parentNode.parentNode;
        var idToMod = tr.childNodes[0].innerHTML
        var listaId = listaPersonas.filter(Cliente => Cliente.getId() == idToMod);
        if (listaId.length > 0) {
            listaPersonas.splice(idToMod, 1);
            var contenedor = (<HTMLTableElement>document.getElementById("agregarPersona"));
            var nombre: string = (<HTMLInputElement>document.getElementById("nombrePost")).value;
            var apellido: string = (<HTMLInputElement>document.getElementById("apellidoPost")).value;
            var edadStr: string = (<HTMLInputElement>document.getElementById("edadPost")).value;
            var tipoPersona = (<HTMLInputElement>document.getElementById("sexoPost")).value;
            var sexoT: eSexo;
            var edadNum:number = parseInt(edadStr);
            
            nombre = tr.children[1].innerHTML;
            apellido = tr.children[2].innerHTML;
            edadNum = tr.children[3].innerHTML;
            tipoPersona = tr.children[4].innerHTML;
            contenedor.hidden = false;
    
            row = tr;
        }
        
        
        
    }

    export function Eliminar(tr: any) {
        var trToDelete = tr.target.parentNode.parentNode;
        var idToDelete = trToDelete.childNodes[0].innerHTML
        var listaId = listaPersonas.filter(Cliente => Cliente.getId() == idToDelete);
        if (listaId.length > 0) {
            listaPersonas.splice(idToDelete, 1);
            var tablaPersonas = (<HTMLTableElement>document.getElementById("tablePersons"));
            var tablaFiltrados = (<HTMLTableElement>document.getElementById("tableFilters"));

            tablaPersonas.childNodes.forEach(element => {
                    if (element.nodeName == "TR") {
                        if (element.childNodes[2].textContent == idToDelete) {
                            element.remove();
                            return;
                        }
                    }
                    trToDelete.remove();
                
            });

            tablaFiltrados.childNodes.forEach(element2 => {
                if (element2.nodeName == "TR") {
                    if (element2.childNodes[2].textContent == idToDelete) {
                        element2.remove();
                        return;
                    }
                }
                trToDelete.remove();
            
            });

        }
    }
    
}